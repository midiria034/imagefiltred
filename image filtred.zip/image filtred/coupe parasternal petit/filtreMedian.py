from PIL import Image, ImageFilter
import os

def median_filter(img):
    return img.filter(ImageFilter.MedianFilter(size=5))

def apply_filter(input_folder, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if filename.endswith(('.jpg', '.png')): # vérifie si l'extension du fichier est correcte
            try:
                img = Image.open(os.path.join(input_folder, filename))
                filtered_img = median_filter(img)
                filtered_img.save(os.path.join(output_folder, filename))
            except IOError:
                print(f"Error: failed to load image {filename}")
        else:
            print(f"Skipping file {filename} with invalid extension")

input_folder = r'C:\Users\mehdi\Desktop\image resized\coupe parasternal petit'
output_folder = r'C:\Users\mehdi\Desktop\image filtred\coupe parasternal petit'
apply_filter(input_folder, output_folder)
